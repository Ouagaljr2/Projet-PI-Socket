#!/bin/bash

python3 client_interface.py
