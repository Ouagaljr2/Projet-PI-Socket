#!/bin/bash

python3 serveur_interface.py
